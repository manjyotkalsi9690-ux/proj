import { redis } from './redis';

export const HOUR_MS = 3_600_000;

/**
 * Reserves one send slot for a sender in the current hour window.
 * INCR is atomic in Redis, so this is correct across any number of workers/instances.
 */
export async function reserveHourlySlot(senderId: number, limit: number) {
  const window = Math.floor(Date.now() / HOUR_MS);
  const key = `ratelimit:sender:${senderId}:${window}`;
  const count = await redis.incr(key);
  if (count === 1) await redis.expire(key, 2 * 3600);

  if (count > limit) {
    await redis.decr(key); // give the slot back; we did not send
    return { allowed: false as const, nextWindowStartMs: (window + 1) * HOUR_MS };
  }
  return { allowed: true as const, nextWindowStartMs: 0 };
}
