import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config';
import { pool } from '../db';
import { requireAuth } from '../middleware';

const router = Router();
const GOOGLE_REDIRECT = `${config.backendUrl}/api/auth/google/callback`;

router.get('/google', (_req, res) => {
  const params = new URLSearchParams({
    client_id: config.google.clientId,
    redirect_uri: GOOGLE_REDIRECT,
    response_type: 'code',
    scope: 'openid email profile',
    prompt: 'select_account',
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
});

router.get('/google/callback', async (req, res) => {
  const code = String(req.query.code ?? '');
  if (!code) return res.redirect(`${config.frontendUrl}/?error=google`);
  try {
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: config.google.clientId,
        client_secret: config.google.clientSecret,
        redirect_uri: GOOGLE_REDIRECT,
        grant_type: 'authorization_code',
      }),
    });
    if (!tokenRes.ok) throw new Error(await tokenRes.text());
    const { access_token } = (await tokenRes.json()) as { access_token: string };

    const profileRes = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
      headers: { Authorization: `Bearer ${access_token}` },
    });
    const profile = (await profileRes.json()) as { sub: string; email: string; name: string; picture?: string };

    const { rows } = await pool.query<{ id: number }>(
      `INSERT INTO users (google_id, email, name, picture) VALUES ($1,$2,$3,$4)
       ON CONFLICT (google_id) DO UPDATE SET email = EXCLUDED.email, name = EXCLUDED.name, picture = EXCLUDED.picture
       RETURNING id`,
      [profile.sub, profile.email, profile.name, profile.picture ?? null],
    );
    const token = jwt.sign({ uid: rows[0].id }, config.jwtSecret, { expiresIn: '7d' });
    res.cookie('session', token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 24 * 3600 * 1000 });
    res.redirect(`${config.frontendUrl}/dashboard`);
  } catch (err) {
    console.error('Google login failed:', err);
    res.redirect(`${config.frontendUrl}/?error=google`);
  }
});

router.get('/me', requireAuth, async (req, res) => {
  const { rows } = await pool.query('SELECT id, name, email, picture FROM users WHERE id = $1', [req.userId]);
  if (!rows[0]) return res.status(401).json({ error: 'User not found' });
  res.json(rows[0]);
});

router.post('/logout', (_req, res) => {
  res.clearCookie('session');
  res.json({ ok: true });
});

export default router;
