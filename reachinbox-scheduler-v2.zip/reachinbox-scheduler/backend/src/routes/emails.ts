import { Router } from 'express';
import { config } from '../config';
import { requireAuth } from '../middleware';
import { getCounts, getEmail, listEmails, scheduleCampaign } from '../emailService';
import { searchEmails } from '../search';

const router = Router();
router.use(requireAuth);

const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

router.post('/schedule', async (req, res, next) => {
  try {
    const { subject, body, recipients, startTime, delayBetweenMs, hourlyLimit } = req.body ?? {};
    if (!subject || !body) return res.status(400).json({ error: 'Subject and body are required' });
    if (!Array.isArray(recipients)) return res.status(400).json({ error: 'recipients must be an array' });

    const emails = [...new Set(recipients.map((r: unknown) => String(r).trim().toLowerCase()).filter(isEmail))];
    if (!emails.length) return res.status(400).json({ error: 'No valid email addresses found' });

    const start = startTime ? new Date(startTime) : new Date();
    if (Number.isNaN(start.getTime())) return res.status(400).json({ error: 'Invalid startTime' });

    const delay = Number(delayBetweenMs ?? 0);
    const limit = Number(hourlyLimit ?? config.maxEmailsPerHour);
    if (!Number.isInteger(delay) || delay < 0) return res.status(400).json({ error: 'delayBetweenMs must be >= 0' });
    if (!Number.isInteger(limit) || limit < 1) return res.status(400).json({ error: 'hourlyLimit must be >= 1' });

    const result = await scheduleCampaign(req.userId!, {
      subject: String(subject),
      body: String(body),
      recipients: emails,
      startTime: start,
      delayBetweenMs: delay,
      hourlyLimit: limit,
    });
    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
});

router.get('/', async (req, res, next) => {
  try {
    const tab = req.query.tab === 'sent' ? 'sent' : 'scheduled';
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
    res.json(await listEmails(req.userId!, tab, page, limit));
  } catch (err) {
    next(err);
  }
});

router.get('/search', async (req, res, next) => {
  try {
    const q = String(req.query.q ?? '').trim();
    if (!q) return res.json([]);
    const docs = await searchEmails(req.userId!, q);
    res.json(
      docs.map((d) => ({
        id: d.id,
        email: d.to_email,
        preview: d.body.slice(0, 160),
        subject: d.subject,
        scheduled_at: d.scheduled_at,
        sent_at: d.sent_at ?? null,
        status: d.status,
        error: d.error ?? null,
      })),
    );
  } catch (err) {
    next(err);
  }
});

router.get('/counts', async (req, res, next) => {
  try {
    res.json(await getCounts(req.userId!));
  } catch (err) {
    next(err);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    if (!/^[0-9a-f-]{36}$/i.test(req.params.id)) return res.status(404).json({ error: 'Email not found' });
    const email = await getEmail(req.userId!, req.params.id);
    if (!email) return res.status(404).json({ error: 'Email not found' });
    res.json(email);
  } catch (err) {
    next(err);
  }
});

export default router;
