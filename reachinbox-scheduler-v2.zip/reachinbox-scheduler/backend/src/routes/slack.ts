import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config';
import { pool } from '../db';
import { requireAuth } from '../middleware';

const router = Router();
const SLACK_REDIRECT = `${config.backendUrl}/api/slack/callback`;

/** Starts the real Slack OAuth flow (incoming-webhook scope). */
router.get('/connect', requireAuth, (req, res) => {
  const state = jwt.sign({ uid: req.userId, purpose: 'slack' }, config.jwtSecret, { expiresIn: '10m' });
  const params = new URLSearchParams({
    client_id: config.slack.clientId,
    scope: 'incoming-webhook',
    redirect_uri: SLACK_REDIRECT,
    state,
  });
  res.redirect(`https://slack.com/oauth/v2/authorize?${params}`);
});

router.get('/callback', async (req, res) => {
  try {
    if (req.query.error || !req.query.code) throw new Error('Slack authorization denied');
    const payload = jwt.verify(String(req.query.state), config.jwtSecret) as { uid: number; purpose: string };
    if (payload.purpose !== 'slack') throw new Error('Invalid state');

    const r = await fetch('https://slack.com/api/oauth.v2.access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code: String(req.query.code),
        client_id: config.slack.clientId,
        client_secret: config.slack.clientSecret,
        redirect_uri: SLACK_REDIRECT,
      }),
    });
    const data = (await r.json()) as {
      ok: boolean;
      error?: string;
      incoming_webhook?: { url: string; channel: string };
    };
    if (!data.ok || !data.incoming_webhook) throw new Error(data.error ?? 'Missing webhook');

    await pool.query('UPDATE users SET slack_webhook_url = $2, slack_channel = $3 WHERE id = $1', [
      payload.uid,
      data.incoming_webhook.url,
      data.incoming_webhook.channel,
    ]);
    res.redirect(`${config.frontendUrl}/dashboard?slack=connected`);
  } catch (err) {
    console.error('Slack OAuth failed:', (err as Error).message);
    res.redirect(`${config.frontendUrl}/dashboard?slack=error`);
  }
});

router.get('/status', requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    'SELECT slack_webhook_url IS NOT NULL AS connected, slack_channel AS channel FROM users WHERE id = $1',
    [req.userId],
  );
  res.json({ connected: Boolean(rows[0]?.connected), channel: rows[0]?.channel ?? null });
});

router.post('/disconnect', requireAuth, async (req, res) => {
  await pool.query('UPDATE users SET slack_webhook_url = NULL, slack_channel = NULL WHERE id = $1', [req.userId]);
  res.json({ ok: true });
});

export default router;
