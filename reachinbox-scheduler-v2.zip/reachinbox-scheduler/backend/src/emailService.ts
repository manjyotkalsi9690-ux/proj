import { randomUUID } from 'crypto';
import { pool } from './db';
import { ensureSenders } from './mailer';
import { emailQueue, toJob } from './queue';
import { indexEmails } from './search';

export interface ScheduleInput {
  subject: string;
  body: string;
  recipients: string[];
  startTime: Date;
  delayBetweenMs: number;
  hourlyLimit: number;
}

const CHUNK = 500;

/** Stores one row per recipient, indexes them for search, and enqueues one delayed job each. */
export async function scheduleCampaign(userId: number, input: ScheduleInput) {
  const senders = await ensureSenders();
  const campaignId = randomUUID();

  const senderIds: number[] = [];
  const times: string[] = [];
  input.recipients.forEach((_, i) => {
    senderIds.push(senders[i % senders.length].id); // round-robin across senders
    times.push(new Date(input.startTime.getTime() + i * input.delayBetweenMs).toISOString());
  });

  const { rows } = await pool.query<{ id: string; to_email: string; scheduled_at: Date }>(
    `INSERT INTO emails (user_id, campaign_id, sender_id, to_email, subject, body, hourly_limit, scheduled_at, status)
     SELECT $1::int, $2::uuid, t.sender_id, t.to_email, $3::text, $4::text, $5::int, t.scheduled_at, 'scheduled'
     FROM unnest($6::int[], $7::text[], $8::timestamptz[]) AS t(sender_id, to_email, scheduled_at)
     RETURNING id, to_email, scheduled_at`,
    [userId, campaignId, input.subject, input.body, input.hourlyLimit, senderIds, input.recipients, times],
  );

  await indexEmails(
    rows.map((r) => ({
      id: r.id,
      user_id: userId,
      to_email: r.to_email,
      subject: input.subject,
      body: input.body,
      status: 'scheduled',
      scheduled_at: r.scheduled_at,
    })),
  );
  await enqueueRows(rows.map((r) => ({ id: r.id, scheduledAt: r.scheduled_at })));
  return { campaignId, scheduled: rows.length };
}

export async function enqueueRows(items: { id: string; scheduledAt: Date }[]) {
  const now = Date.now();
  const jobs = items.map((i) => toJob(i.id, new Date(i.scheduledAt).getTime() - now));
  for (let i = 0; i < jobs.length; i += CHUNK) {
    await emailQueue.addBulk(jobs.slice(i, i + CHUNK));
  }
}

/** Runs on boot: rebuilds any missing delayed jobs from Postgres (the source of truth). */
export async function reconcileOnStartup() {
  // Rows stuck in 'sending' for >5 min are from a crash; put them back (at-least-once, see README).
  const reset = await pool.query(
    `UPDATE emails SET status = 'scheduled', claimed_at = NULL
      WHERE status = 'sending' AND claimed_at < now() - interval '5 minutes'`,
  );
  const { rows } = await pool.query<{ id: string; scheduled_at: Date }>(
    `SELECT id, scheduled_at FROM emails WHERE status = 'scheduled'`,
  );
  await enqueueRows(rows.map((r) => ({ id: r.id, scheduledAt: r.scheduled_at })));
  return { requeued: rows.length, resetSending: reset.rowCount ?? 0 };
}

export async function listEmails(userId: number, tab: 'scheduled' | 'sent', page: number, limit: number) {
  const statuses = tab === 'scheduled' ? ['scheduled', 'sending'] : ['sent', 'failed'];
  const order = tab === 'scheduled' ? 'scheduled_at ASC' : 'COALESCE(sent_at, scheduled_at) DESC';
  const [items, total] = await Promise.all([
    pool.query(
      `SELECT id, to_email AS email, subject, LEFT(body, 160) AS preview, scheduled_at, sent_at, status, error
         FROM emails WHERE user_id = $1 AND status = ANY($2)
         ORDER BY ${order} LIMIT $3 OFFSET $4`,
      [userId, statuses, limit, (page - 1) * limit],
    ),
    pool.query<{ n: number }>(
      'SELECT COUNT(*)::int AS n FROM emails WHERE user_id = $1 AND status = ANY($2)',
      [userId, statuses],
    ),
  ]);
  return { items: items.rows, total: total.rows[0].n };
}

export async function getEmail(userId: number, id: string) {
  const { rows } = await pool.query(
    `SELECT id, to_email AS email, subject, body, scheduled_at, sent_at, status, error
       FROM emails WHERE id = $1 AND user_id = $2`,
    [id, userId],
  );
  return rows[0] ?? null;
}

export async function getCounts(userId: number) {
  const { rows } = await pool.query(
    `SELECT COUNT(*) FILTER (WHERE status IN ('scheduled','sending'))::int AS scheduled,
            COUNT(*) FILTER (WHERE status IN ('sent','failed'))::int AS sent
       FROM emails WHERE user_id = $1`,
    [userId],
  );
  return rows[0] as { scheduled: number; sent: number };
}
