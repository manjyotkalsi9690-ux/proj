import { pool } from './db';
import { redis } from './redis';

/**
 * Posts to the user's Slack incoming webhook when a sender hits its hourly limit.
 * The webhook is read from the DB on every call, so connecting Slack later works without a redeploy.
 * Not connected -> silently skip. At most one message per sender per hour.
 */
export async function notifyRateLimitHit(userId: number, senderEmail: string, limit: number) {
  const { rows } = await pool.query<{ slack_webhook_url: string | null }>(
    'SELECT slack_webhook_url FROM users WHERE id = $1',
    [userId],
  );
  const url = rows[0]?.slack_webhook_url;
  if (!url) return;

  const window = Math.floor(Date.now() / 3_600_000);
  const first = await redis.set(`slack:notified:${senderEmail}:${window}`, '1', 'EX', 7200, 'NX');
  if (!first) return;

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: `:warning: Hourly limit reached for sender *${senderEmail}* (${limit} emails/hour). Remaining emails were rescheduled to the next hour window.`,
      }),
    });
    if (!res.ok) console.warn('Slack webhook responded with', res.status);
  } catch (err) {
    console.warn('Slack notification failed (non-fatal):', (err as Error).message);
  }
}
