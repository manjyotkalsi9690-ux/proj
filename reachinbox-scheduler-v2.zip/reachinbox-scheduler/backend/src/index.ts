import express from 'express';
import cookieParser from 'cookie-parser';
import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import { ExpressAdapter } from '@bull-board/express';
import { config } from './config';
import { initSchema, pool } from './db';
import { ensureSenders } from './mailer';
import { ensureEmailIndex } from './search';
import { emailQueue } from './queue';
import { startWorker } from './worker';
import { reconcileOnStartup } from './emailService';
import authRoutes from './routes/auth';
import emailRoutes from './routes/emails';
import slackRoutes from './routes/slack';

async function main() {
  // Boot order matters: schema -> senders -> index -> re-enqueue persisted work -> start workers.
  await initSchema();
  await ensureSenders();
  await ensureEmailIndex().catch((e) => console.warn('ES index setup skipped:', e.message));
  const recovered = await reconcileOnStartup();
  console.log('Recovered scheduled work:', recovered);
  const worker = startWorker();

  const app = express();
  app.use(express.json({ limit: '5mb' }));
  app.use(cookieParser());

  app.use('/api/auth', authRoutes);
  app.use('/api/emails', emailRoutes);
  app.use('/api/slack', slackRoutes);

  // Live BullMQ dashboard (polls Redis for queue state).
  const serverAdapter = new ExpressAdapter();
  serverAdapter.setBasePath('/admin/queues');
  createBullBoard({ queues: [new BullMQAdapter(emailQueue)], serverAdapter });
  app.use('/admin/queues', serverAdapter.getRouter());

  app.get('/health', async (_req, res) => {
    await pool.query('SELECT 1');
    res.json({ ok: true });
  });

  app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  });

  const server = app.listen(config.port, () => {
    console.log(`API on :${config.port}  |  Queue dashboard on :${config.port}/admin/queues`);
  });

  // Graceful shutdown: finish in-flight sends, leave everything else persisted in Redis/Postgres.
  const shutdown = async () => {
    server.close();
    await worker.close();
    await emailQueue.close();
    await pool.end();
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
