import { Client } from '@elastic/elasticsearch';
import { config } from './config';

export const EMAIL_INDEX = 'emails';
export const es = new Client({ node: config.esNode });

export interface EmailDoc {
  id: string;
  user_id: number;
  to_email: string;
  subject: string;
  body: string;
  status: string;
  scheduled_at: Date | string;
  sent_at?: Date | string | null;
  error?: string | null;
}

export async function ensureEmailIndex() {
  const exists = await es.indices.exists({ index: EMAIL_INDEX });
  if (exists) return;
  await es.indices.create({
    index: EMAIL_INDEX,
    mappings: {
      properties: {
        user_id: { type: 'integer' },
        to_email: { type: 'keyword' },
        subject: { type: 'text' },
        body: { type: 'text' },
        status: { type: 'keyword' },
        scheduled_at: { type: 'date' },
        sent_at: { type: 'date' },
        error: { type: 'text' },
      },
    },
  });
}

/** Search indexing is best-effort: a failed index never blocks or fails a send. */
export async function indexEmails(docs: EmailDoc[]) {
  if (!docs.length) return;
  try {
    const operations = docs.flatMap((d) => [{ index: { _index: EMAIL_INDEX, _id: d.id } }, d]) as any[];
    const res = await es.bulk({ operations, refresh: false });
    if (res.errors) console.warn('Elasticsearch bulk indexing had item errors');
  } catch (err) {
    console.warn('Elasticsearch indexing failed (non-fatal):', (err as Error).message);
  }
}

export async function searchEmails(userId: number, q: string, limit = 50): Promise<EmailDoc[]> {
  const res = await es.search<EmailDoc>({
    index: EMAIL_INDEX,
    size: limit,
    query: {
      bool: {
        filter: [{ term: { user_id: userId } }],
        must: [{ multi_match: { query: q, fields: ['to_email^3', 'subject^2', 'body'] } }],
      },
    },
    sort: [{ scheduled_at: { order: 'desc' } }],
  });
  return res.hits.hits.map((h) => h._source!);
}
