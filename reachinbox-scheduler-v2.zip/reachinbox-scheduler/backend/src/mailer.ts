import nodemailer from 'nodemailer';
import { pool } from './db';
import { config } from './config';

export interface Sender {
  id: number;
  email: string;
  smtp_host: string;
  smtp_port: number;
  smtp_user: string;
  smtp_pass: string;
}

const transports = new Map<number, nodemailer.Transporter>();

/**
 * Creates Ethereal test inboxes once and persists them in Postgres,
 * so a restart reuses the same senders instead of creating new ones.
 */
export async function ensureSenders(): Promise<Sender[]> {
  const { rows } = await pool.query<{ count: string }>('SELECT COUNT(*) FROM senders');
  for (let i = Number(rows[0].count); i < config.senderCount; i++) {
    const account = await nodemailer.createTestAccount();
    await pool.query(
      'INSERT INTO senders (email, smtp_host, smtp_port, smtp_user, smtp_pass) VALUES ($1,$2,$3,$4,$5)',
      [account.user, account.smtp.host, account.smtp.port, account.user, account.pass],
    );
  }
  const res = await pool.query<Sender>('SELECT * FROM senders ORDER BY id LIMIT $1', [config.senderCount]);
  return res.rows;
}

export async function getSender(id: number): Promise<Sender> {
  const { rows } = await pool.query<Sender>('SELECT * FROM senders WHERE id = $1', [id]);
  if (!rows[0]) throw new Error(`Sender ${id} not found`);
  return rows[0];
}

function transportFor(s: Sender) {
  let t = transports.get(s.id);
  if (!t) {
    t = nodemailer.createTransport({
      host: s.smtp_host,
      port: s.smtp_port,
      secure: false,
      auth: { user: s.smtp_user, pass: s.smtp_pass },
    });
    transports.set(s.id, t);
  }
  return t;
}

export async function sendMail(sender: Sender, to: string, subject: string, text: string) {
  const info = await transportFor(sender).sendMail({ from: sender.email, to, subject, text });
  return { messageId: info.messageId, previewUrl: nodemailer.getTestMessageUrl(info) || null };
}
