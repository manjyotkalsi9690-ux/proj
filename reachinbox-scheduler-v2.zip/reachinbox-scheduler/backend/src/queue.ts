import { Queue, JobsOptions } from 'bullmq';
import { config } from './config';
import { newRedis } from './redis';

export interface SendJobData {
  emailId: string;
}

export const emailQueue = new Queue<SendJobData>(config.queueName, {
  connection: newRedis(),
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: { age: 24 * 3600, count: 10000 },
    removeOnFail: { age: 7 * 24 * 3600 },
  },
});

/**
 * One delayed job per email row. jobId is deterministic, so BullMQ ignores
 * a second add for the same email: re-enqueueing after a restart cannot duplicate work.
 */
export function toJob(emailId: string, delayMs: number): { name: string; data: SendJobData; opts: JobsOptions } {
  return {
    name: 'send',
    data: { emailId },
    opts: { jobId: `email-${emailId}`, delay: Math.max(0, delayMs) },
  };
}
