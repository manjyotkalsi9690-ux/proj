import 'dotenv/config';

const num = (name: string, fallback: number): number => {
  const v = process.env[name];
  return v === undefined || v === '' ? fallback : Number(v);
};
const str = (name: string, fallback = ''): string => process.env[name] ?? fallback;

export const config = {
  port: num('PORT', 4000),
  backendUrl: str('BACKEND_URL', 'http://localhost:4000'),
  frontendUrl: str('FRONTEND_URL', 'http://localhost:5173'),
  databaseUrl: str('DATABASE_URL', 'postgres://postgres:postgres@localhost:5432/reachinbox'),
  redisUrl: str('REDIS_URL', 'redis://localhost:6379'),
  esNode: str('ES_NODE', 'http://localhost:9200'),
  jwtSecret: str('JWT_SECRET', 'dev-secret-change-me'),
  google: { clientId: str('GOOGLE_CLIENT_ID'), clientSecret: str('GOOGLE_CLIENT_SECRET') },
  slack: { clientId: str('SLACK_CLIENT_ID'), clientSecret: str('SLACK_CLIENT_SECRET') },
  workerConcurrency: num('WORKER_CONCURRENCY', 5),
  sendMinDelayMs: num('SEND_MIN_DELAY_MS', 2000),
  maxEmailsPerHour: num('MAX_EMAILS_PER_HOUR', 200),
  senderCount: num('SENDER_COUNT', 3),
  queueName: 'email-send',
};
