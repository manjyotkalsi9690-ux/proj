import { Worker, Job, DelayedError } from 'bullmq';
import { config } from './config';
import { pool } from './db';
import { newRedis } from './redis';
import { getSender, sendMail } from './mailer';
import { reserveHourlySlot } from './rateLimit';
import { notifyRateLimitHit } from './slack';
import { indexEmails } from './search';
import { SendJobData } from './queue';

interface EmailRow {
  id: string;
  user_id: number;
  sender_id: number;
  to_email: string;
  subject: string;
  body: string;
  hourly_limit: number;
  status: string;
  scheduled_at: Date;
  sent_at: Date | null;
  error: string | null;
}

async function processSendJob(job: Job<SendJobData>, token?: string) {
  const { emailId } = job.data;

  // 1. Claim the row. Only one worker can flip scheduled -> sending, so duplicates never send twice.
  const claimed = await pool.query<EmailRow>(
    `UPDATE emails SET status = 'sending', claimed_at = now()
      WHERE id = $1 AND status = 'scheduled'
      RETURNING id, user_id, sender_id, to_email, subject, body, hourly_limit`,
    [emailId],
  );
  const email = claimed.rows[0];
  if (!email) return { skipped: 'already processed or cancelled' };

  // 2. Enforce the hourly cap per sender (Redis counter shared by all workers).
  const sender = await getSender(email.sender_id);
  const limit = Math.min(config.maxEmailsPerHour, email.hourly_limit);
  const slot = await reserveHourlySlot(sender.id, limit);

  if (!slot.allowed) {
    // Do not drop or fail: release the row and park the job until the next hour window.
    await pool.query(`UPDATE emails SET status = 'scheduled', claimed_at = NULL WHERE id = $1`, [emailId]);
    await notifyRateLimitHit(email.user_id, sender.email, limit);
    await job.moveToDelayed(slot.nextWindowStartMs, token);
    throw new DelayedError();
  }

  // 3. Send. On failure, retry via BullMQ; mark failed only on the final attempt.
  try {
    const sent = await sendMail(sender, email.to_email, email.subject, email.body);
    const { rows } = await pool.query<EmailRow>(
      `UPDATE emails SET status = 'sent', sent_at = now(), message_id = $2, claimed_at = NULL
        WHERE id = $1 RETURNING *`,
      [emailId, sent.messageId],
    );
    await indexEmails([rows[0]]);
    return { messageId: sent.messageId, previewUrl: sent.previewUrl };
  } catch (err) {
    const isFinal = job.attemptsMade + 1 >= (job.opts.attempts ?? 1);
    const { rows } = await pool.query<EmailRow>(
      `UPDATE emails SET status = $2, error = $3, claimed_at = NULL WHERE id = $1 RETURNING *`,
      [emailId, isFinal ? 'failed' : 'scheduled', String(err)],
    );
    if (isFinal) await indexEmails([rows[0]]);
    throw err;
  }
}

export function startWorker() {
  const worker = new Worker<SendJobData>(config.queueName, processSendJob, {
    connection: newRedis(),
    concurrency: config.workerConcurrency,
    // Global throttle across all workers and instances: at most one job starts per SEND_MIN_DELAY_MS.
    limiter: { max: 1, duration: config.sendMinDelayMs },
  });

  worker.on('completed', (job, result) => console.log(`[send] ${job.data.emailId}`, result));
  worker.on('failed', (job, err) => console.error(`[send] ${job?.data.emailId} failed:`, err.message));
  return worker;
}
