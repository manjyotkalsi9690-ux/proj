import IORedis from 'ioredis';
import { config } from './config';

/** Shared client for plain commands (rate-limit counters, dedupe keys). */
export const redis = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

/** BullMQ needs its own connections (blocking commands), so it gets fresh ones. */
export const newRedis = () => new IORedis(config.redisUrl, { maxRetriesPerRequest: null });
