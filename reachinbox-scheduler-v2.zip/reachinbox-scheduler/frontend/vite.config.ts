import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Proxying /api keeps the session cookie same-origin, so no CORS config is needed in dev.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': { target: 'http://localhost:4000', changeOrigin: true },
    },
  },
});
