import type { Counts, EmailDetail, EmailRow, Page, ScheduleInput, ScheduleResult, SlackStatus, User } from './types';

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(`/api${path}`, {
    credentials: 'include',
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init.headers ?? {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? `Request failed (${res.status})`);
  return data as T;
}

export const api = {
  me: () => request<User>('/auth/me'),
  logout: () => request<{ ok: boolean }>('/auth/logout', { method: 'POST' }),
  listEmails: (tab: 'scheduled' | 'sent', page: number, limit: number) =>
    request<Page<EmailRow>>(`/emails?tab=${tab}&page=${page}&limit=${limit}`),
  search: (q: string) => request<EmailRow[]>(`/emails/search?q=${encodeURIComponent(q)}`),
  getEmail: (id: string) => request<EmailDetail>(`/emails/${id}`),
  counts: () => request<Counts>('/emails/counts'),
  schedule: (input: ScheduleInput) =>
    request<ScheduleResult>('/emails/schedule', { method: 'POST', body: JSON.stringify(input) }),
  slackStatus: () => request<SlackStatus>('/slack/status'),
  slackDisconnect: () => request<{ ok: boolean }>('/slack/disconnect', { method: 'POST' }),
};
