const EMAIL_RE = /^[^\s@,;"]+@[^\s@,;"]+\.[^\s@,;"]+$/;

/**
 * Extracts unique, valid email addresses from CSV or plain text.
 * Header rows and non-email cells are ignored automatically.
 */
export function parseRecipients(text: string): string[] {
  const tokens = text
    .split(/[\s,;]+/)
    .map((t) => t.trim().replace(/^"+|"+$/g, '').toLowerCase())
    .filter(Boolean);
  return [...new Set(tokens.filter((t) => EMAIL_RE.test(t)))];
}
