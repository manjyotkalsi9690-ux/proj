export interface User {
  id: number;
  name: string;
  email: string;
  picture: string | null;
}

export type EmailStatus = 'scheduled' | 'sending' | 'sent' | 'failed';

export interface EmailRow {
  id: string;
  email: string;
  subject: string;
  preview?: string;
  scheduled_at: string;
  sent_at: string | null;
  status: EmailStatus;
  error: string | null;
}

export interface EmailDetail extends EmailRow {
  body: string;
}

export interface Counts {
  scheduled: number;
  sent: number;
}

export interface Page<T> {
  items: T[];
  total: number;
}

export interface SlackStatus {
  connected: boolean;
  channel: string | null;
}

export interface ScheduleInput {
  subject: string;
  body: string;
  recipients: string[];
  startTime: string;
  delayBetweenMs: number;
  hourlyLimit: number;
}

export interface ScheduleResult {
  campaignId: string;
  scheduled: number;
}
