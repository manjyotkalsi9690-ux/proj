import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { RefreshCw, Search } from 'lucide-react';
import { api } from '../api';
import { useToast } from '../context/ToastContext';
import type { EmailRow, Page } from '../types';
import { Button, EmptyState, StatusPill } from '../components/ui';

const PAGE_SIZE = 20;

export default function InboxPage() {
  const { tab: rawTab } = useParams();
  const tab = rawTab === 'sent' ? 'sent' : 'scheduled';
  const navigate = useNavigate();
  const { notify } = useToast();

  const [page, setPage] = useState(1);
  const [data, setData] = useState<Page<EmailRow>>({ items: [], total: 0 });
  const [loading, setLoading] = useState(true);
  const [reloadKey, setReloadKey] = useState(0);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<EmailRow[] | null>(null);

  useEffect(() => setPage(1), [tab]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .listEmails(tab, page, PAGE_SIZE)
      .then((d) => !cancelled && setData(d))
      .catch((e) => notify('error', e.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [tab, page, reloadKey, notify]);

  useEffect(() => {
    if (!query.trim()) return setResults(null);
    const t = setTimeout(() => {
      api.search(query.trim()).then(setResults).catch((e) => notify('error', e.message));
    }, 350);
    return () => clearTimeout(t);
  }, [query, notify]);

  const showingSearch = results !== null;
  const rows = showingSearch ? results : data.items;
  const totalPages = Math.max(1, Math.ceil(data.total / PAGE_SIZE));

  return (
    <>
      <div className="flex items-center gap-3 border-b border-slate-200 px-6 py-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search"
            aria-label="Search emails"
            className="w-full rounded-lg bg-slate-100 py-2.5 pl-9 pr-3 text-sm outline-none placeholder:text-slate-400 focus:ring-2 focus:ring-brand/30"
          />
        </div>
        <button
          onClick={() => {
            setQuery('');
            setReloadKey((k) => k + 1);
          }}
          aria-label="Refresh"
          className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
        >
          <RefreshCw size={16} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {loading && !showingSearch ? (
          <div className="space-y-px p-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="mb-2 h-11 animate-pulse rounded-lg bg-slate-100" />
            ))}
          </div>
        ) : rows && rows.length > 0 ? (
          rows.map((row) => (
            <button
              key={row.id}
              onClick={() => navigate(`/emails/${row.id}`)}
              className="flex w-full items-center gap-4 border-b border-slate-100 px-6 py-3.5 text-left text-sm hover:bg-slate-50"
            >
              <span className="w-56 shrink-0 truncate text-slate-700">To: {row.email}</span>
              <StatusPill status={row.status} scheduledAt={row.scheduled_at} />
              <span className="min-w-0 flex-1 truncate">
                <span className="font-medium text-slate-900">{row.subject}</span>
                {row.preview && <span className="text-slate-400"> - {row.preview}</span>}
              </span>
            </button>
          ))
        ) : (
          <EmptyState
            title={showingSearch ? 'No matching emails' : tab === 'scheduled' ? 'No scheduled emails' : 'No sent emails yet'}
            description={showingSearch ? 'Try a different search term.' : 'Compose a campaign to get started.'}
          />
        )}
      </div>

      {!showingSearch && !loading && data.total > PAGE_SIZE && (
        <div className="flex items-center justify-end gap-3 border-t border-slate-200 px-6 py-3 text-sm text-slate-500">
          <Button variant="secondary" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            Previous
          </Button>
          <span>
            Page {page} of {totalPages}
          </span>
          <Button variant="secondary" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
            Next
          </Button>
        </div>
      )}
    </>
  );
}
