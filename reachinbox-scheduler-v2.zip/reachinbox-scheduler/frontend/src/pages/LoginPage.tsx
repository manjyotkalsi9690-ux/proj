import { FormEvent, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useToast } from '../context/ToastContext';
import { Button, Input } from '../components/ui';

export default function LoginPage() {
  const [params] = useSearchParams();
  const { notify } = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // The design includes email/password login, but the backend only implements Google OAuth.
  const onEmailLogin = (e: FormEvent) => {
    e.preventDefault();
    notify('error', 'Email and password sign-in is not enabled yet. Please use Google.');
  };

  return (
    <div className="grid min-h-screen place-items-center bg-white px-4">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 p-10 shadow-sm">
        <h1 className="text-center text-3xl font-bold">Login</h1>
        {params.get('error') && (
          <p className="mt-4 text-center text-sm text-red-500">Google sign-in failed. Please try again.</p>
        )}

        <a
          href="/api/auth/google"
          className="mt-8 flex w-full items-center justify-center gap-2 rounded-lg bg-brand-soft py-3 text-sm font-medium text-slate-800 hover:brightness-95"
        >
          <span className="text-base font-bold text-[#4285F4]">G</span>
          Login with Google
        </a>

        <div className="my-6 flex items-center gap-3 text-xs text-slate-400">
          <span className="h-px flex-1 bg-slate-200" />
          or sign up through email
          <span className="h-px flex-1 bg-slate-200" />
        </div>

        <form onSubmit={onEmailLogin} className="space-y-3">
          <Input placeholder="Email ID" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <Button type="submit" className="mt-2 w-full">
            Login
          </Button>
        </form>
      </div>
    </div>
  );
}
