import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock } from 'lucide-react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Button, Input, Row } from '../components/ui';
import RecipientInput from '../components/RecipientInput';
import RichEditor from '../components/RichEditor';
import SendLaterPopover from '../components/SendLaterPopover';

export default function ComposePage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { notify } = useToast();

  const [recipients, setRecipients] = useState<string[]>([]);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [delaySec, setDelaySec] = useState(2);
  const [hourlyLimit, setHourlyLimit] = useState(200);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [sending, setSending] = useState(false);

  async function send() {
    if (!recipients.length) return notify('error', 'Add at least one recipient');
    if (!subject.trim()) return notify('error', 'Add a subject');
    if (!body.trim()) return notify('error', 'Write a message');

    setSending(true);
    try {
      const res = await api.schedule({
        subject,
        body,
        recipients,
        startTime: (startTime ?? new Date()).toISOString(),
        delayBetweenMs: delaySec * 1000,
        hourlyLimit,
      });
      notify('success', `Scheduled ${res.scheduled} emails`);
      navigate('/dashboard/scheduled');
    } catch (err) {
      notify('error', (err as Error).message);
    } finally {
      setSending(false);
    }
  }

  return (
    <>
      <header className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} aria-label="Back" className="text-slate-500 hover:text-slate-900">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-lg font-semibold">Compose New Email</h1>
        </div>
        <div className="relative flex items-center gap-2">
          <button
            onClick={() => setPopoverOpen((o) => !o)}
            aria-label="Schedule"
            title="Send later"
            className={`rounded-lg p-2 hover:bg-slate-100 ${startTime ? 'text-brand' : 'text-slate-500'}`}
          >
            <Clock size={18} />
          </button>
          {popoverOpen && (
            <SendLaterPopover value={startTime} onChange={setStartTime} onClose={() => setPopoverOpen(false)} />
          )}
          <Button variant="outline" loading={sending} onClick={send}>
            {startTime ? 'Send Later' : 'Send'}
          </Button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl space-y-5 px-6 py-8">
          <Row label="From">
            <div className="rounded-lg bg-slate-100 px-3 py-2 text-sm text-slate-700">{user?.email}</div>
          </Row>
          <Row label="To">
            <RecipientInput value={recipients} onChange={setRecipients} />
          </Row>
          <Row label="Subject">
            <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Subject" />
          </Row>
          <div className="flex flex-wrap items-center gap-6 text-sm text-slate-500">
            <label className="flex items-center gap-2">
              Delay between emails (sec)
              <Input
                type="number"
                min={0}
                value={delaySec}
                onChange={(e) => setDelaySec(Number(e.target.value))}
                className="w-20"
              />
            </label>
            <label className="flex items-center gap-2">
              Hourly limit
              <Input
                type="number"
                min={1}
                value={hourlyLimit}
                onChange={(e) => setHourlyLimit(Number(e.target.value))}
                className="w-24"
              />
            </label>
          </div>
          <RichEditor onChange={setBody} />
        </div>
      </div>
    </>
  );
}
