import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import type { EmailDetail } from '../types';
import { fmtDate } from '../lib/format';
import { EmptyState, StatusPill } from '../components/ui';

export default function EmailDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [email, setEmail] = useState<EmailDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    api
      .getEmail(id)
      .then(setEmail)
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="p-10 text-sm text-slate-400">Loading…</div>;
  if (notFound || !email) return <EmptyState title="Email not found" description="It may have been deleted." />;

  return (
    <>
      <header className="flex items-center gap-3 border-b border-slate-200 px-6 py-4">
        <button onClick={() => navigate(-1)} aria-label="Back" className="text-slate-500 hover:text-slate-900">
          <ArrowLeft size={20} />
        </button>
        <h1 className="min-w-0 flex-1 truncate text-lg font-semibold">{email.subject}</h1>
        <StatusPill status={email.status} scheduledAt={email.scheduled_at} />
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl px-6 py-8">
          <div className="flex items-start gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-brand text-sm font-semibold text-white">
              {user?.name.charAt(0)}
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-semibold">{user?.name}</p>
              <p className="text-sm text-slate-500">to {email.email}</p>
            </div>
            <p className="shrink-0 text-sm text-slate-400">{fmtDate(email.sent_at ?? email.scheduled_at)}</p>
          </div>

          <div className="mt-8 whitespace-pre-wrap text-sm leading-6 text-slate-800">{email.body}</div>

          {email.error && (
            <div className="mt-8 rounded-lg bg-red-50 p-3 text-sm text-red-700">Delivery failed: {email.error}</div>
          )}
        </div>
      </div>
    </>
  );
}
