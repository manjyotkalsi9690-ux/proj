import { useState } from 'react';
import { Button } from './ui';
import { toLocalInput } from '../lib/format';

interface Props {
  value: Date | null;
  onChange: (d: Date | null) => void;
  onClose: () => void;
}

const tomorrowAt = (hour: number) => {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(hour, 0, 0, 0);
  return d;
};

const quickOptions = [
  { label: 'Tomorrow', date: tomorrowAt(9) },
  { label: 'Tomorrow, 10:00 AM', date: tomorrowAt(10) },
  { label: 'Tomorrow, 11:00 AM', date: tomorrowAt(11) },
  { label: 'Tomorrow, 3:00 PM', date: tomorrowAt(15) },
];

export default function SendLaterPopover({ value, onChange, onClose }: Props) {
  const [draft, setDraft] = useState(toLocalInput(value ?? new Date(Date.now() + 3_600_000)));

  return (
    <div className="absolute right-0 top-12 z-20 w-72 rounded-xl border border-slate-200 bg-white p-4 shadow-xl">
      <p className="font-semibold">Send Later</p>
      <input
        type="datetime-local"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        aria-label="Pick date and time"
        className="mt-3 w-full rounded-lg bg-slate-100 px-3 py-2 text-sm outline-none"
      />
      <ul className="mt-3 space-y-0.5">
        {quickOptions.map((o) => (
          <li key={o.label}>
            <button
              onClick={() => setDraft(toLocalInput(o.date))}
              className="w-full rounded-md px-3 py-2 text-left text-sm hover:bg-slate-100"
            >
              {o.label}
            </button>
          </li>
        ))}
      </ul>
      <div className="mt-4 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button
          variant="outline"
          onClick={() => {
            onChange(new Date(draft));
            onClose();
          }}
        >
          Done
        </Button>
      </div>
    </div>
  );
}
