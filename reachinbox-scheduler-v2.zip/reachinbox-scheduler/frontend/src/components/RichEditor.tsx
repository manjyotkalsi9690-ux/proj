import { useRef, useState } from 'react';
import { Bold, Italic, List, ListOrdered, Quote, Redo2, Strikethrough, Underline, Undo2, type LucideIcon } from 'lucide-react';

interface Tool {
  label: string;
  cmd: string;
  arg?: string;
  icon: LucideIcon;
}

const groups: Tool[][] = [
  [
    { label: 'Undo', cmd: 'undo', icon: Undo2 },
    { label: 'Redo', cmd: 'redo', icon: Redo2 },
  ],
  [
    { label: 'Bold', cmd: 'bold', icon: Bold },
    { label: 'Italic', cmd: 'italic', icon: Italic },
    { label: 'Underline', cmd: 'underline', icon: Underline },
    { label: 'Strikethrough', cmd: 'strikeThrough', icon: Strikethrough },
  ],
  [
    { label: 'Numbered list', cmd: 'insertOrderedList', icon: ListOrdered },
    { label: 'Bullet list', cmd: 'insertUnorderedList', icon: List },
    { label: 'Quote', cmd: 'formatBlock', arg: 'blockquote', icon: Quote },
  ],
];

interface Props {
  onChange: (text: string) => void;
}

/**
 * Lightweight rich-text toolbar built on contentEditable.
 * Emails are sent as plain text, so formatting is visual only (see README).
 */
export default function RichEditor({ onChange }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [empty, setEmpty] = useState(true);

  const sync = () => {
    const text = ref.current?.innerText ?? '';
    setEmpty(!text.trim());
    onChange(text);
  };

  const exec = (cmd: string, arg?: string) => {
    ref.current?.focus();
    document.execCommand(cmd, false, arg);
    sync();
  };

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200">
      <div className="flex flex-wrap items-center gap-1 border-b border-slate-200 bg-slate-50 px-2 py-1.5">
        {groups.map((group, gi) => (
          <div key={gi} className="flex items-center gap-0.5">
            {gi > 0 && <span className="mx-1 h-5 w-px bg-slate-200" />}
            {group.map((t) => (
              <button
                key={t.label}
                type="button"
                title={t.label}
                aria-label={t.label}
                onMouseDown={(e) => e.preventDefault()} // keep the text selection
                onClick={() => exec(t.cmd, t.arg)}
                className="rounded p-1.5 text-slate-500 hover:bg-slate-200"
              >
                <t.icon size={16} />
              </button>
            ))}
          </div>
        ))}
      </div>
      <div className="relative min-h-[320px] bg-slate-50/60">
        {empty && (
          <div className="pointer-events-none absolute left-4 top-3 text-sm text-slate-400">Type your reply…</div>
        )}
        <div
          ref={ref}
          contentEditable
          suppressContentEditableWarning
          onInput={sync}
          aria-label="Email body"
          className="min-h-[320px] whitespace-pre-wrap px-4 py-3 text-sm leading-6 outline-none"
        />
      </div>
    </div>
  );
}
