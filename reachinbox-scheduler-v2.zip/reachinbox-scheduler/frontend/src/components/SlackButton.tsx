import { useEffect, useState } from 'react';
import { api } from '../api';
import type { SlackStatus } from '../types';
import { useToast } from '../context/ToastContext';

export default function SlackButton() {
  const { notify } = useToast();
  const [status, setStatus] = useState<SlackStatus | null>(null);

  useEffect(() => {
    api.slackStatus().then(setStatus).catch(() => setStatus({ connected: false, channel: null }));
  }, []);

  if (!status) return null;

  if (!status.connected) {
    // Full-page navigation so the backend can run the real Slack OAuth redirect.
    return (
      <button
        onClick={() => (window.location.href = '/api/slack/connect')}
        className="w-full rounded-lg px-3 py-2 text-left text-sm text-slate-500 hover:bg-slate-50"
      >
        # Connect Slack alerts
      </button>
    );
  }

  const disconnect = async () => {
    try {
      await api.slackDisconnect();
      setStatus({ connected: false, channel: null });
      notify('success', 'Slack disconnected');
    } catch (err) {
      notify('error', (err as Error).message);
    }
  };

  return (
    <div className="flex items-center justify-between rounded-lg px-3 py-2 text-xs text-slate-500">
      <span>Slack {status.channel ? `· ${status.channel}` : 'connected'}</span>
      <button onClick={disconnect} className="text-slate-400 hover:text-slate-700">
        Disconnect
      </button>
    </div>
  );
}
