import { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from 'react';
import { Clock } from 'lucide-react';
import type { EmailStatus } from '../../types';
import { fmtPill } from '../../lib/format';

export function Spinner() {
  return <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />;
}

type Variant = 'primary' | 'outline' | 'secondary' | 'ghost' | 'danger';
const variants: Record<Variant, string> = {
  primary: 'bg-brand text-white hover:bg-brand-dark',
  outline: 'border border-brand bg-white text-brand hover:bg-brand-soft',
  secondary: 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50',
  ghost: 'text-slate-600 hover:bg-slate-100',
  danger: 'bg-red-600 text-white hover:bg-red-500',
};

export function Button({
  variant = 'primary',
  loading = false,
  className = '',
  disabled,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; loading?: boolean }) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={`inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-50 ${variants[variant]} ${className}`}
    >
      {loading && <Spinner />}
      {children}
    </button>
  );
}

export function Input({ className = '', ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...rest}
      className={`w-full rounded-lg bg-slate-100 px-3 py-2 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:ring-2 focus:ring-brand/30 ${className}`}
    />
  );
}

const pillTones: Record<EmailStatus, string> = {
  scheduled: 'bg-orange-50 text-orange-600',
  sending: 'bg-sky-50 text-sky-600',
  sent: 'bg-slate-100 text-slate-600',
  failed: 'bg-red-50 text-red-600',
};

/** Orange clock + time for scheduled mail; plain label once it has left the queue. */
export function StatusPill({ status, scheduledAt }: { status: EmailStatus; scheduledAt: string }) {
  if (status === 'scheduled') {
    return (
      <span className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ${pillTones.scheduled}`}>
        <Clock size={12} />
        {fmtPill(scheduledAt)}
      </span>
    );
  }
  const label = status === 'sending' ? 'Sending' : status === 'sent' ? 'Sent' : 'Failed';
  return (
    <span className={`inline-flex shrink-0 items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${pillTones[status]}`}>
      {label}
    </span>
  );
}

export function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="py-20 text-center">
      <p className="text-base font-medium text-slate-800">{title}</p>
      <p className="mt-1 text-sm text-slate-400">{description}</p>
    </div>
  );
}

export function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-start gap-4">
      <span className="w-16 shrink-0 pt-2 text-sm text-slate-500">{label}</span>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  );
}
