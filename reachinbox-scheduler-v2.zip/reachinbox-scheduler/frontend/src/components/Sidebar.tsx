import { useEffect, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Clock, LogOut, Send, type LucideIcon } from 'lucide-react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import type { Counts } from '../types';
import SlackButton from './SlackButton';

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [counts, setCounts] = useState<Counts>({ scheduled: 0, sent: 0 });

  // Refresh badge counts whenever the route changes (after sending, opening, etc.).
  useEffect(() => {
    api.counts().then(setCounts).catch(() => undefined);
  }, [location.pathname]);

  return (
    <aside className="flex w-64 shrink-0 flex-col border-r border-slate-200 p-4">
      <div className="px-2 py-3 font-mono text-2xl font-black tracking-widest">ONB</div>

      {user && (
        <div className="mt-2 flex items-center gap-3 rounded-xl border border-slate-200 p-2.5">
          {user.picture ? (
            <img src={user.picture} alt="" referrerPolicy="no-referrer" className="h-9 w-9 rounded-full" />
          ) : (
            <div className="grid h-9 w-9 place-items-center rounded-full bg-brand text-sm font-semibold text-white">
              {user.name.charAt(0)}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{user.name}</p>
            <p className="truncate text-xs text-slate-400">{user.email}</p>
          </div>
          <button onClick={logout} title="Logout" className="text-slate-400 hover:text-slate-700">
            <LogOut size={16} />
          </button>
        </div>
      )}

      <button
        onClick={() => navigate('/compose')}
        className="mt-3 w-full rounded-lg border border-brand py-2 text-sm font-medium text-brand hover:bg-brand-soft"
      >
        Compose
      </button>

      <p className="mt-6 px-3 text-xs font-medium uppercase tracking-wide text-slate-400">Core</p>
      <nav className="mt-2 space-y-1">
        <NavItem to="/dashboard/scheduled" icon={Clock} label="Scheduled" count={counts.scheduled} />
        <NavItem to="/dashboard/sent" icon={Send} label="Sent" count={counts.sent} />
      </nav>

      <div className="mt-auto pt-4">
        <SlackButton />
      </div>
    </aside>
  );
}

function NavItem({ to, icon: Icon, label, count }: { to: string; icon: LucideIcon; label: string; count: number }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
          isActive ? 'bg-brand-soft font-medium text-brand' : 'text-slate-600 hover:bg-slate-50'
        }`
      }
    >
      <span className="flex items-center gap-3">
        <Icon size={16} />
        {label}
      </span>
      <span className="text-xs text-slate-400">{count}</span>
    </NavLink>
  );
}
