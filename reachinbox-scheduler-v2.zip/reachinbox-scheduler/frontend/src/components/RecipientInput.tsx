import { KeyboardEvent, useRef, useState } from 'react';
import { Upload, X } from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { parseRecipients } from '../lib/parseRecipients';

const isValid = (s: string) => /^[^\s@,;"]+@[^\s@,;"]+\.[^\s@,;"]+$/.test(s);
const VISIBLE = 3;

interface Props {
  value: string[];
  onChange: (next: string[]) => void;
}

/** Chip-based "To" field with a "+N" overflow and an Upload List button. */
export default function RecipientInput({ value, onChange }: Props) {
  const { notify } = useToast();
  const [text, setText] = useState('');
  const [expanded, setExpanded] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const commit = () => {
    const tokens = text.split(/[\s,;]+/).map((s) => s.trim().toLowerCase()).filter(Boolean);
    if (!tokens.length) return;
    const valid = tokens.filter(isValid);
    if (valid.length < tokens.length) notify('error', `${tokens.length - valid.length} invalid address(es) skipped`);
    onChange([...new Set([...value, ...valid])]);
    setText('');
  };

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (['Enter', ',', ';', ' '].includes(e.key)) {
      e.preventDefault();
      commit();
    } else if (e.key === 'Backspace' && !text && value.length) {
      onChange(value.slice(0, -1));
    }
  };

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const parsed = parseRecipients(await file.text());
    onChange([...new Set([...value, ...parsed])]);
    notify(parsed.length ? 'success' : 'error', parsed.length ? `${parsed.length} addresses added from ${file.name}` : 'No valid email addresses in that file');
    e.target.value = '';
  }

  const shown = expanded ? value : value.slice(0, VISIBLE);
  const hidden = value.length - shown.length;

  return (
    <div className="flex items-start gap-3">
      <div className="flex min-h-10 flex-1 flex-wrap items-center gap-1.5 border-b border-slate-200 py-1.5">
        {shown.map((email) => (
          <span
            key={email}
            className="flex items-center gap-1 rounded-full border border-brand/40 bg-brand-soft px-2.5 py-0.5 text-xs text-brand-dark"
          >
            {email}
            <button onClick={() => onChange(value.filter((v) => v !== email))} aria-label={`Remove ${email}`}>
              <X size={12} />
            </button>
          </span>
        ))}
        {hidden > 0 && (
          <button
            onClick={() => setExpanded(true)}
            className="rounded-full bg-brand-soft px-2.5 py-0.5 text-xs font-medium text-brand-dark"
          >
            +{hidden}
          </button>
        )}
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={onKeyDown}
          onBlur={commit}
          placeholder={value.length ? '' : 'recipient@example.com'}
          aria-label="Recipients"
          className="min-w-[160px] flex-1 bg-transparent py-1 text-sm outline-none placeholder:text-slate-400"
        />
      </div>
      <button
        onClick={() => fileRef.current?.click()}
        className="flex shrink-0 items-center gap-1 pt-2 text-sm text-brand hover:underline"
      >
        <Upload size={14} /> Upload List
      </button>
      <input ref={fileRef} type="file" accept=".csv,.txt" className="hidden" onChange={onFile} />
    </div>
  );
}
