# ReachInbox – Email Job Scheduler

A scheduler that accepts email campaigns via API, delays each send to its scheduled time using BullMQ on Redis, sends through Ethereal SMTP, enforces per-sender hourly limits, alerts Slack when limits are hit, indexes everything in Elasticsearch, and survives restarts without losing or duplicating work.

```
frontend/   React + Vite + TypeScript + Tailwind (dashboard, compose, tables)
backend/    Express + TypeScript + BullMQ worker + Postgres + Elasticsearch + Slack/Google OAuth
docker-compose.yml   Postgres, Redis (AOF on), Elasticsearch
```

## 1. Quick start

**Prerequisites:** Node 18+, Docker.

```bash
# 1. Infra
docker compose up -d

# 2. Backend
cd backend
cp .env.example .env          # fill in Google + Slack credentials (see section 3)
npm install
npm run dev                   # API on :4000, BullMQ dashboard on :4000/admin/queues

# 3. Frontend (new terminal)
cd frontend
npm install
npm run dev                   # http://localhost:5173
```

Open http://localhost:5173, sign in with Google, and click **Compose New Email**.

Tables load from Postgres. Search uses Elasticsearch. The queue dashboard is at http://localhost:4000/admin/queues.

## 2. Ethereal Email setup

No manual setup is needed. On first boot the backend calls `nodemailer.createTestAccount()` `SENDER_COUNT` times, and each account is stored in the `senders` table. Restarts reuse the same accounts.

To inspect sent mail, open https://ethereal.email and log in with a sender's `email` and `smtp_pass` (both in the `senders` table). Each send also logs a preview URL in the backend console.

## 3. OAuth setup

**Google login**
1. Google Cloud Console → APIs & Services → Credentials → Create OAuth client (Web application).
2. Authorized redirect URI: `http://localhost:4000/api/auth/google/callback`
3. Put the client ID and secret in `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`.

**Slack alerts**
1. api.slack.com/apps → Create New App → From scratch.
2. OAuth & Permissions → Redirect URL: `http://localhost:4000/api/slack/callback`
3. Bot token scopes are not needed. The flow requests the `incoming-webhook` user scope, which returns a webhook URL bound to a channel the user picks.
4. Put the Client ID and Secret in `SLACK_CLIENT_ID` / `SLACK_CLIENT_SECRET`.

Click **Connect Slack** in the header. Once connected, the next time a sender hits its hourly limit, a message appears in that channel. Disconnect and reconnect at any time without restarting the server.

## 4. Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `WORKER_CONCURRENCY` | 5 | Parallel jobs per worker process |
| `SEND_MIN_DELAY_MS` | 2000 | Minimum gap between any two sends (global) |
| `MAX_EMAILS_PER_HOUR` | 200 | Hard cap per sender per hour window |
| `SENDER_COUNT` | 3 | Number of Ethereal senders to provision |
| `DATABASE_URL`, `REDIS_URL`, `ES_NODE` | localhost | Service endpoints |
| `JWT_SECRET` | – | Signs session cookies and OAuth state. Set a long random value. |

## 5. Architecture

### Scheduling
`POST /api/emails/schedule` takes subject, body, recipients, `startTime`, `delayBetweenMs`, and `hourlyLimit`. For recipient *i*, the scheduled time is `startTime + i × delayBetweenMs`. The backend:

1. Inserts one `emails` row per recipient in a single `INSERT … SELECT FROM unnest(...)`. Senders are assigned round-robin.
2. Indexes the rows in Elasticsearch with one bulk call.
3. Adds one **BullMQ delayed job** per row, with `delay = scheduled_at − now`. No cron or polling loop is involved. Redis holds the timer.

### Persistence across restarts
- **Postgres is the source of truth** for each email's state. Redis holds the timers.
- **Redis runs with AOF** (`--appendonly yes`), so delayed jobs survive a Redis restart.
- **On boot, `reconcileOnStartup()`** finds every row still in `scheduled` and re-adds its job. BullMQ ignores an add with an existing `jobId`, so this is a no-op for jobs already in Redis and restores any that are missing.
- Rows stuck in `sending` for more than 5 minutes after a crash are reset to `scheduled`.

### Idempotency (no duplicates)
- `jobId = email-<uuid>` means one job per row. A second enqueue is ignored by BullMQ.
- The worker claims a row with `UPDATE … SET status='sending' WHERE id=$1 AND status='scheduled'`. Only one worker can win that update. Any duplicate job finds no row and exits.
- Retries (up to 3 with exponential backoff) move the row back to `scheduled`. Only the final failed attempt marks the row `failed`.

### Concurrency and throttling
- **Worker concurrency** is `WORKER_CONCURRENCY`. Jobs in one process run in parallel, and any number of processes can share the queue safely because all state lives in Redis and Postgres.
- **Minimum delay between sends** uses BullMQ's limiter: `limiter: { max: 1, duration: SEND_MIN_DELAY_MS }`. This is global across all workers and instances, so the default enforces at least 2 seconds between sends.

### Hourly rate limit
- Per sender, per hour window: `INCR ratelimit:sender:<id>:<floor(now/1h)>` in Redis, with a 2-hour TTL.
- The effective limit is `min(MAX_EMAILS_PER_HOUR, campaign hourly limit)`.
- If `INCR` returns a value above the limit, the worker `DECR`s it back, releases the row to `scheduled`, and calls `job.moveToDelayed(nextHourStart)`. The job is rescheduled into the next hour window and is not dropped or failed.
- Because `INCR` is atomic in Redis, the counter is correct across any number of workers.

### Slack alert on limit hit
- When a limit is hit, the worker reads the user's webhook from Postgres and POSTs to it.
- Deduplication: `SET slack:notified:<sender>:<hour> NX EX 7200` ensures at most one message per sender per hour.
- Not connected → skipped silently. Connected later → the next hit notifies, with no redeploy.

### Behavior under load
- **1,000+ emails at the same time:** all 1,000 jobs are enqueued in chunks of 500 and become due together. The limiter serializes sends to one per `SEND_MIN_DELAY_MS`, so ~33 minutes for 1,000 at 2 s. Jobs beyond a sender's hourly cap are moved to the next hour. Nothing is lost and nothing fails.
- **Rate limit exceeded:** the job is delayed to the next window, the row returns to `scheduled`, and Slack is notified once.

### Elasticsearch
Each email is indexed as a document with `user_id`, `to_email`, `subject`, `body`, `status`, and timestamps. Search runs `multi_match` on address, subject, and body, filtered to the current user. Indexing failures are logged and do not affect sending.

## 6. Features mapped to requirements

**Backend**
- [x] Email scheduling API (`POST /api/emails/schedule`)
- [x] Postgres persistence (`emails`, `senders`, `users`)
- [x] BullMQ delayed jobs, no cron
- [x] Multiple senders via Ethereal, round-robin
- [x] Elasticsearch indexing and search (`GET /api/emails/search`)
- [x] Live BullMQ dashboard (`/admin/queues`)
- [x] Restart persistence and reconciliation
- [x] Idempotent sends (jobId + conditional claim)
- [x] Configurable worker concurrency
- [x] Minimum delay between sends (limiter)
- [x] Hourly rate limit per sender, Redis-backed, rescheduled (not dropped)
- [x] Slack OAuth connect, live webhook notification, disconnect/reconnect handling

**Frontend**
- [x] Google OAuth login (real flow), redirect to dashboard
- [x] Header with name, email, avatar, logout
- [x] Scheduled / Sent tabs with pagination
- [x] Loading states and empty states
- [x] Compose modal: subject, body, CSV/text upload with email count, start time, delay, hourly limit
- [x] Search box (Elasticsearch)
- [x] Connect/Disconnect Slack button, toasts for OAuth results
- [x] Reusable UI components, TypeScript types for API responses and props

## 7. Assumptions, shortcuts, and trade-offs

- **Ethereal is test SMTP.** Mail is never delivered to real inboxes. Sender accounts are created automatically.
- **Single-tenant Slack.** Each user connects their own Slack webhook. Multi-workspace installs would need a Slack app distribution flow.
- **Order is best-effort.** BullMQ does not guarantee FIFO for jobs with the same timestamp. When rate-limited, all deferred jobs for a sender move to the same next-hour timestamp, so their order within that hour is not strictly preserved. The send-time ordering is preserved by the per-recipient timestamps.
- **At-least-once on crashes.** If the process dies after SMTP accepts a message but before Postgres is updated, the row is retried after 5 minutes and that email may be sent twice. Exactly-once would require the SMTP provider to support idempotency keys.
- **Global throttle, not per-sender.** The minimum-delay limiter is queue-wide, which is stricter than necessary when several senders exist. Per-sender limiters are a straightforward extension.
- **Rate limit counts attempts, not successes.** A send that fails after claiming a slot still uses that slot in the hour window.
- **Dashboard is unauthenticated.** `/admin/queues` should sit behind basic auth or VPN in any shared environment.
- **Figma was not provided.** The UI follows the functional spec with a clean dark theme; pixel-matching the Figma is a styling pass once the design is shared.

## 8. Demo checklist (5 min)

1. Sign in with Google → show name, email, avatar.
2. Connect Slack → show the connected badge.
3. Compose: upload a CSV → show the detected count. Set a start time 1 minute ahead, a 10-second delay, and hourly limit 3.
4. Show **Scheduled** rows counting down; open `/admin/queues` to show delayed jobs.
5. **Restart:** `Ctrl+C` the backend, restart with `npm run dev`. Log shows “Recovered scheduled work”. Future emails still send on time.
6. Show **Sent** rows and the Ethereal preview URLs in the console.
7. **Rate limit:** with hourly limit 3 and 5 recipients, the 4th and 5th are deferred and a Slack message appears.
8. Search a recipient address in the search box.
